---
title: "케이디님의 '유니티로 생존 게임 만들기' 강의 필기"
layout: archive
permalink: categories/unity-lesson-3
author_profile: true
sidebar_main: true
---

<!-- 공백이 포함되어 있는 카테고리 이름의 경우 site.categories['a b c'] 이런식으로! -->

***

인프런에 있는 케이디님의 **[유니티 3D] 실전! 생존게임 만들기 - Advanced** 강의를 듣고 정리한 필기입니다. 😀 언제든지 다시 참고할 수 있도록, 지식 공유보단 개인적인 복습을 목적으로 포스팅하였습니다. <br> [🌜 강의 들으러 가기 Click](https://www.inflearn.com/course/unity-2#)
{: .notice--warning}

{% assign posts = site.categories['Unity Lesson 3'] %}
{% for post in posts %} {% include archive-single2.html type=page.entries_layout %} {% endfor %}