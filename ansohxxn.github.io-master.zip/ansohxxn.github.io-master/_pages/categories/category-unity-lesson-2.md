---
title: "Rookiss님의 '[MMORPG 게임 개발 시리즈] Part3: 유니티 엔진' 강의 필기"
layout: archive
permalink: categories/unity-lesson-2
author_profile: true
sidebar_main: true
---

<!-- 공백이 포함되어 있는 카테고리 이름의 경우 site.categories['a b c'] 이런식으로! -->

***

인프런에 있는 Rookiss님의 **[C#과 유니티로 만드는 MMORPG 게임 개발 시리즈] Part3: 유니티 엔진** 강의를 듣고 정리한 필기입니다. 😀 언제든지 다시 참고할 수 있도록, 지식 공유보단 개인적인 복습을 목적으로 포스팅하였습니다. 유니티 배우시는 분들께 도시락 싸들고 다니면서 추천하고 싶은 그런 명강의입니다. 프레임워크를 구축하는 식의 코드를 가르쳐주시기 때문에 정말 많은 도움이 되었습니다. 추천함다...👍 (광고 아니에여..) <br> [🌜 강의 들으러 가기 Click](https://www.inflearn.com/course/MMORPG-유니티)
{: .notice--warning}

{% assign posts = site.categories['Unity Lesson 2'] %}
{% for post in posts %} {% include archive-single2.html type=page.entries_layout %} {% endfor %}

