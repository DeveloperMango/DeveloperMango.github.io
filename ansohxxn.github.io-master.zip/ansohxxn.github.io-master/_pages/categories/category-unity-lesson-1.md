---
title: "레트로의 유니티 C# 게임 프로그래밍 에센스 강의 필기"
layout: archive
permalink: categories/unity-lesson-1
author_profile: true
sidebar_main: true
---

<!-- 공백이 포함되어 있는 카테고리 이름의 경우 site.categories['a b c'] 이런식으로! -->

***

인프런에 있는 이제민님의 **레트로의 유니티 C# 게임 프로그래밍 에센스** 강의를 듣고 정리한 필기입니다. 😀 언제든지 다시 참고할 수 있도록, 지식 공유보단 개인적인 복습을 목적으로 포스팅하였습니다. 저는 이 강의로 유니티를 처음 접하였는데 기초부터 차근 차근 설명을 잘 해주셔서 이해에 많은 도움이 되었습니다. 정말 좋은 강의이니 강력 추천합니다! (광고 아니에여..☆) <br> [🌜 [레트로의 유니티 C# 게임 프로그래밍 에센스] 강의 보러가기!](https://www.inflearn.com/course/%EC%9C%A0%EB%8B%88%ED%8B%B0-%EA%B2%8C%EC%9E%84-%ED%94%84%EB%A1%9C%EA%B7%B8%EB%9E%98%EB%B0%8D-%EC%97%90%EC%84%BC%EC%8A%A4)
{: .notice--warning}

{% assign posts = site.categories['Unity Lesson 1'] %}
{% for post in posts %} {% include archive-single2.html type=page.entries_layout %} {% endfor %}